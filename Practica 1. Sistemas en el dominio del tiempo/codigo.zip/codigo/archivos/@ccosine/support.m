function supp = support(sig)
supp = [sig.Delay sig.Delay+sig.Length];