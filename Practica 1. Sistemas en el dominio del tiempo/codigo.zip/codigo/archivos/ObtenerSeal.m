function varargout = ObtenerSe�al(varargin)
% OBTENERSE�AL M-file for ObtenerSe�al.fig
%      OBTENERSE�AL, by itself, creates a new OBTENERSE�AL or raises the existing
%      singleton*.
%
%      H = OBTENERSE�AL returns the handle to a new OBTENERSE�AL or the handle to
%      the existing singleton*.
%
%      OBTENERSE�AL('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in OBTENERSE�AL.M with the given input arguments.
%
%      OBTENERSE�AL('Property','Value',...) creates a new OBTENERSE�AL or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before ObtenerSe�al_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to ObtenerSe�al_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help ObtenerSe�al

% Last Modified by GUIDE v2.5 03-Jul-2004 00:57:46


%Declaramos una serie de variables globales
global tipo_senal_moduladora fm senal_moduladora fs ejes_tiempo ejes_freq

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ObtenerSe�al_OpeningFcn, ...
                   'gui_OutputFcn',  @ObtenerSe�al_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before ObtenerSe�al is made visible.
function ObtenerSe�al_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to ObtenerSe�al (see VARARGIN)

% Choose default command line output for ObtenerSe�al
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ObtenerSe�al wait for user response (see UIRESUME)
% uiwait(handles.figure1);

global ejes_tiempo ejes_freq

ejes_tiempo = varargin{1};
ejes_freq = varargin{2};


% --- Outputs from this function are returned to the command line.
function varargout = ObtenerSe�al_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



% --- Executes on selection change in listbox1.
function listbox1_Callback(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns listbox1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from listbox1


% --- Executes during object creation, after setting all properties.
function listbox1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to listbox1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end


% --- Executes on selection change in menuSelectModuladora.
function menuSelectModuladora_Callback(hObject, eventdata, handles)
% hObject    handle to menuSelectModuladora (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = get(hObject,'String') returns menuSelectModuladora contents as cell array
%        contents{get(hObject,'Value')} returns selected item from menuSelectModuladora

global tipo_senal_moduladora

%Obtenemos el �ndice de la se�al que se desea modular
tipo_senal_moduladora = get(hObject,'Value');


% --- Executes during object creation, after setting all properties.
function menuSelectModuladora_CreateFcn(hObject, eventdata, handles)
% hObject    handle to menuSelectModuladora (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc
    set(hObject,'BackgroundColor','white');
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

global tipo_senal_moduladora

if size(tipo_senal_moduladora) == [0 0];
    tipo_senal_moduladora = get(hObject,'Value');
else
    set(hObject, 'Value', tipo_senal_moduladora);
end


% --- Executes on button press in BotonRetornar.
function BotonRetornar_Callback(hObject, eventdata, handles)
% hObject    handle to BotonRetornar (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global senal_moduladora fm tipo_senal_moduladora fs ejes_tiempo ejes_freq

%Creamos la se�al de salida
load handel;
N1=4;
y = y(1:N1:round(end/2));
N2=8;
y=interp(y,N2);
fs = round(N2*Fs/N1);
t=(0:(length(y)-1))./fs;

switch tipo_senal_moduladora
    case 1,
        senal_moduladora = sin(2*pi*fm*t);
        ajuste_ejes = [0 5/fm -1.1 1.1];
    case 2,
        senal_moduladora = (sin(2*pi*fm*t)>0);
        ajuste_ejes = [0 5/fm -.1 1.1];
    otherwise,
        senal_moduladora = y;
        ajuste_ejes = [0 length(y)/(100*fs) -1.1 1.1];
end

%Pintamos las figuras en los ejes
%Dibujamos la se�al seleccionada en nuestros ejes
plot(ejes_tiempo,t,senal_moduladora)
axis(ejes_tiempo, ajuste_ejes)
xlabel(ejes_tiempo,'tiempo [s]')
ylabel(ejes_tiempo,'Amplitud')

%Dibujamos el espectro de la se�al moduladora en nuestros ejes
espectro = abs(fftshift(fft(senal_moduladora,1.5*length(senal_moduladora))));
espectro = espectro/(length(senal_moduladora));
w=linspace(-pi*fs,pi*fs,1.5*length(senal_moduladora));

plot(ejes_freq,w,espectro)
axis(ejes_freq,[-pi*fs pi*fs 0 1.1*max(espectro)])
xlabel(ejes_freq,'Frecuencia angular [rad/s]')
ylabel(ejes_freq,'|TF{}|')


%Cerramos la figura actual
close(gcf)


% --- Executes on slider movement.
function SelecFmod_Callback(hObject, eventdata, handles)
% hObject    handle to SelecFmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider

%Obtenemos el valor de la barra deslizante
global fm

fval = get(hObject,'Value');
fm = fval*1e2;
set(handles.TextoBarraDes,'String',['100Hz     ',int2str(round(fm)),'Hz     500Hz']);


% --- Executes during object creation, after setting all properties.
function SelecFmod_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SelecFmod (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background, change
%       'usewhitebg' to 0 to use default.  See ISPC and COMPUTER.
usewhitebg = 1;
if usewhitebg
    set(hObject,'BackgroundColor',[.9 .9 .9]);
else
    set(hObject,'BackgroundColor',get(0,'defaultUicontrolBackgroundColor'));
end

%Definimos el valor por defecto de la frecuencia de la moduladora
global fm

if (size(fm) == [0 0]) | ~exist('fm') ;
    fm = get(hObject, 'Value')*1e2;
else
    set(hObject, 'Value', fm/1e2);
end

