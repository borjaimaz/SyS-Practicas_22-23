function PracticaSyC2(Jstate)

%Universidad Rey Juan Carlos
%Ingenier�a de Telecomunicaci�n
%Se�ales y Comunicaciones

%Pr�ctica 2 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% En la segunda pr�ctica se pretende afianzar el concepto de convoluci�n,
% la interfaz es sencilla e intuitiva.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Jstate;
cconvdemo



%Teor�a de la se�al y las comunicaciones (27/09/2004)